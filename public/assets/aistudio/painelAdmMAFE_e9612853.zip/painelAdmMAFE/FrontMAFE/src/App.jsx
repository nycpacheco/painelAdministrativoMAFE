// src/App.jsx
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Login } from "./components/routes/Login";
import { AdminDashboard } from "./components/routes/AdminDashboard"; // Componente que contém as 4 abas
import { ProtectedRoute } from "./components/routes/ProtectedRoute";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* 1. Rota Pública de Login */}
        <Route path="/login" element={<Login />} />

        {/* 2. Rotas Protegidas do Painel Admin (Exigem login) */}
        <Route element={<ProtectedRoute />}>
          {/* O /admin vai carregar o painel com as abas */}
          <Route path="/admin" element={<AdminDashboard />} />
        </Route>

        {/* 3. Redirecionamento padrão caso digite uma URL inválida */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
