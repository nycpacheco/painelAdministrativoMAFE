// src/components/ui/ApoiadorDetailModal/ApoiadorDetailModal.jsx
import styles from './ApoiadorDetailModal.module.css';

export function ApoiadorDetailModal({ isOpen, onClose, apoiador, onEdit, onDelete, onToggleAtivo }) {
  if (!isOpen || !apoiador) return null;

  return (
    <div className={styles.backdrop}>
      <div className={styles.modal}>
        <div className={styles.modalHeader}>
          <h3>🔍 Detalhes do Apoiador (ID: {apoiador.id})</h3>
          <button onClick={onClose} className={styles.closeButton}>✕</button>
        </div>

        <div className={styles.modalBody}>
          <div className={styles.mediaContainer}>
            {apoiador.logo_url ? (
              <img src={apoiador.logo_url} alt={apoiador.nome_empresa} className={styles.largeImage} />
            ) : (
              <div className={styles.noMedia}>Sem logo disponível</div>
            )}
          </div>

          <div className={styles.infoContainer}>
            <div className={styles.badgesRow}>
              <span className={apoiador.ativo ? styles.statusAtivo : styles.statusInativo}>
                {apoiador.ativo ? '● Ativo' : '○ Inativo'}
              </span>
            </div>

            <h2 className={styles.titulo}>{apoiador.nome_empresa}</h2>
            
            <div className={styles.metaInfo}>
              <p><strong>Visualizações:</strong> {apoiador.visualizacoes || 0}</p>
            </div>

            {apoiador.site_url && (
              <p>
                <strong>Website:</strong>{' '}
                <a href={apoiador.site_url} target="_blank" rel="noopener noreferrer" className={styles.siteLink}>
                  {apoiador.site_url}
                </a>
              </p>
            )}

            <div className={styles.descricaoBox}>
              <strong>Descrição / Apoio:</strong>
              <p>{apoiador.descricao || 'Nenhuma descrição informada.'}</p>
            </div>
          </div>
        </div>

        <div className={styles.modalActions}>
          <button 
            onClick={() => onToggleAtivo(apoiador)} 
            className={apoiador.ativo ? styles.deactivateButton : styles.activateButton}
          >
            {apoiador.ativo ? 'Desativar' : 'Ativar'}
          </button>
          <button 
            onClick={() => { onClose(); onEdit(apoiador); }} 
            className={styles.editButton}
          >
            ✏️ Editar
          </button>
          <button 
            onClick={() => { if(confirm("Deseja excluir permanentemente este apoiador?")) { onDelete(apoiador.id); onClose(); } }} 
            className={styles.deleteButton}
          >
            🗑️ Excluir
          </button>
          <button onClick={onClose} className={styles.closeModalButton}>
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}