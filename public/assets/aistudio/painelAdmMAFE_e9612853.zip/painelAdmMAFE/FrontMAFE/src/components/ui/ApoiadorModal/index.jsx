// src/components/ui/ApoiadorModal/ApoiadorModal.jsx
import { useState, useEffect } from 'react';
import styles from './ApoiadorModal.module.css';

export function ApoiadorModal({ isOpen, onClose, onSave, apoiadorParaEditar }) {
  const [nomeEmpresa, setNomeEmpresa] = useState('');
  const [descricao, setDescricao] = useState('');
  const [logoUrl, setLogoUrl] = useState('');
  const [siteUrl, setSiteUrl] = useState('');
  const [ativo, setAtivo] = useState(true);
  const [erroUrl, setErroUrl] = useState(false);

  useEffect(() => {
    if (apoiadorParaEditar) {
      setNomeEmpresa(apoiadorParaEditar.nome_empresa || '');
      setDescricao(apoiadorParaEditar.descricao || '');
      setLogoUrl(apoiadorParaEditar.logo_url || '');
      setSiteUrl(apoiadorParaEditar.site_url || '');
      setAtivo(apoiadorParaEditar.ativo !== undefined ? apoiadorParaEditar.ativo : true);
    } else {
      setNomeEmpresa('');
      setDescricao('');
      setLogoUrl('');
      setSiteUrl('');
      setAtivo(true);
    }
    setErroUrl(false);
  }, [apoiadorParaEditar, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!nomeEmpresa.trim() || !logoUrl.trim()) {
      alert("Preencha os campos obrigatórios (Nome da Empresa e URL do Logo).");
      return;
    }

    const dadosFormulario = {
      nome_empresa: nomeEmpresa,
      descricao,
      logo_url: logoUrl,
      site_url: siteUrl,
      ativo
    };

    onSave(dadosFormulario);
  };

  return (
    <div className={styles.backdrop}>
      <div className={styles.modal}>
        <div className={styles.modalHeader}>
          <h3>{apoiadorParaEditar ? '✏️ Editar Apoiador' : '➕ Adicionar Novo Apoiador'}</h3>
          <button onClick={onClose} className={styles.closeButton}>✕</button>
        </div>

        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.inputGroup}>
            <label>Nome da Empresa / Apoiador *</label>
            <input
              type="text"
              value={nomeEmpresa}
              onChange={(e) => setNomeEmpresa(e.target.value)}
              placeholder="Ex: Prefeitura de Bragança Paulista"
              required
              className={styles.input}
            />
          </div>

          <div className={styles.inputGroup}>
            <label>Descrição / Apoio Institucional</label>
            <textarea
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              placeholder="Detalhes sobre a parceria..."
              className={styles.textarea}
              rows="3"
            />
          </div>

          <div className={styles.inputGroup}>
            <label>URL do Logo *</label>
            <input
              type="url"
              value={logoUrl}
              onChange={(e) => {
                setLogoUrl(e.target.value);
                setErroUrl(false);
              }}
              placeholder="https://exemplo.com/logo.png"
              required
              className={styles.input}
            />
          </div>

          {logoUrl && (
            <div className={styles.previewContainer}>
              <span className={styles.previewLabel}>Pré-visualização do Logo:</span>
              <div className={styles.imagePreviewBox}>
                <img
                  src={logoUrl}
                  alt="Preview"
                  className={styles.previewImage}
                  onError={() => setErroUrl(true)}
                  onLoad={() => setErroUrl(false)}
                />
                {erroUrl && (
                  <span className={styles.errorText}>⚠️ Não foi possível carregar a imagem desta URL.</span>
                )}
              </div>
            </div>
          )}

          <div className={styles.inputGroup}>
            <label>URL do Site / Redes Sociais</label>
            <input
              type="url"
              value={siteUrl}
              onChange={(e) => setSiteUrl(e.target.value)}
              placeholder="https://instagram.com/parceiro"
              className={styles.input}
            />
          </div>

          <div className={styles.inputGroup}>
            <label>Status *</label>
            <select
              value={ativo ? 'true' : 'false'}
              onChange={(e) => setAtivo(e.target.value === 'true')}
              className={styles.select}
            >
              <option value="true">● Ativo (Visível)</option>
              <option value="false">○ Inativo (Oculto)</option>
            </select>
          </div>

          <div className={styles.modalActions}>
            <button type="button" onClick={onClose} className={styles.cancelButton}>
              Cancelar
            </button>
            <button type="submit" className={styles.saveButton}>
              {apoiadorParaEditar ? 'Salvar Alterações' : 'Cadastrar Apoiador'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}