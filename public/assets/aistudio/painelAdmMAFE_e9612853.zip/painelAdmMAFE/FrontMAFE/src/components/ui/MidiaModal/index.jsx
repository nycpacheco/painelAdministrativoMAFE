// src/components/ui/MidiaModal/MidiaModal.jsx
import { useState, useEffect } from 'react';
import styles from './MidiaModal.module.css';

export function MidiaModal({ isOpen, onClose, onSave, midiaParaEditar, categorias, anosDisponiveis }) {
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [urlMidia, setUrlMidia] = useState('');
  const [tipoMidia, setTipoMidia] = useState('foto');
  const [categoriaId, setCategoriaId] = useState('');
  const [ano, setAno] = useState('');
  const [ativo, setAtivo] = useState(true);
  const [erroUrl, setErroUrl] = useState(false);

  useEffect(() => {
    if (midiaParaEditar) {
      setTitulo(midiaParaEditar.titulo || '');
      setDescricao(midiaParaEditar.descricao || '');
      setUrlMidia(midiaParaEditar.url_midia || '');
      setTipoMidia(midiaParaEditar.tipo_midia || 'foto');
      setCategoriaId(midiaParaEditar.categoria_id ? String(midiaParaEditar.categoria_id) : (categorias[0]?.id ? String(categorias[0].id) : ''));
      setAno(midiaParaEditar.ano ? String(midiaParaEditar.ano) : (anosDisponiveis[0] ? String(anosDisponiveis[0]) : new Date().getFullYear()));
      setAtivo(midiaParaEditar.ativo !== undefined ? midiaParaEditar.ativo : true);
    } else {
      // Modo Criação: Valores padrão inteligentes
      setTitulo('');
      setDescricao('');
      setUrlMidia('');
      setTipoMidia('foto');
      setCategoriaId(categorias[0]?.id ? String(categorias[0].id) : '');
      setAno(anosDisponiveis[0] ? String(anosDisponiveis[0]) : String(new Date().getFullYear()));
      setAtivo(true);
    }
    setErroUrl(false);
  }, [midiaParaEditar, isOpen, categorias, anosDisponiveis]);

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!titulo.trim() || !urlMidia.trim()) {
      alert("Preencha os campos obrigatórios (Título e URL).");
      return;
    }

    const dadosFormulario = {
      titulo,
      descricao,
      url_midia: urlMidia,
      tipo_midia: tipoMidia,
      categoria_id: Number(categoriaId),
      ano: Number(ano),
      ativo
    };

    onSave(dadosFormulario);
  };

  return (
    <div className={styles.backdrop}>
      <div className={styles.modal}>
        <div className={styles.modalHeader}>
          <h3>{midiaParaEditar ? '✏️ Editar Mídia' : '➕ Adicionar Nova Mídia'}</h3>
          <button onClick={onClose} className={styles.closeButton}>✕</button>
        </div>

        <form onSubmit={handleSubmit} className={styles.form}>
          {/* Campos de Texto Livre */}
          <div className={styles.inputGroup}>
            <label>Título da Mídia *</label>
            <input
                type="text"
                value={titulo}
                onChange={(e) => setTitulo(e.target.value)}
                placeholder="Ex: Torneio de Vôlei Adaptado"
                required
                className={styles.input}
                />
            </div>
            
          <div className={styles.inputGroup}>
            <label>Descrição</label>
            <textarea
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              placeholder="Detalhes sobre o momento ou evento..."
              className={styles.textarea}
              rows="3"
            />
          </div>

          <div className={styles.inputGroup}>
            <label>URL da Mídia (Imagem/Vídeo) *</label>
            <input
              type="url"
              value={urlMidia}
              onChange={(e) => {
                setUrlMidia(e.target.value);
                setErroUrl(false);
              }}
              placeholder="https://exemplo.com/imagem.jpg"
              required
              className={styles.input}
            />
          </div>

          {/* Preview ao Vivo da Mídia */}
          {urlMidia && (
            <div className={styles.previewContainer}>
              <span className={styles.previewLabel}>Pré-visualização ao vivo:</span>
              <div className={styles.imagePreviewBox}>
                <img
                  src={urlMidia}
                  alt="Preview"
                  className={styles.previewImage}
                  onError={() => setErroUrl(true)}
                  onLoad={() => setErroUrl(false)}
                />
                {erroUrl && (
                  <span className={styles.errorText}>⚠️ Não foi possível carregar a imagem desta URL.</span>
                )}
              </div>
            </div>
          )}

          {/* Restrições Inteligentes (Selects restritos Poka-Yoke) */}
          <div className={styles.rowGrid}>
            <div className={styles.inputGroup}>
              <label>Categoria *</label>
              <select
                value={categoriaId}
                onChange={(e) => setCategoriaId(e.target.value)}
                className={styles.select}
                required
              >
                {categorias.map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.nome}</option>
                ))}
              </select>
            </div>

            <div className={styles.inputGroup}>
              <label>Ano *</label>
              <select
                value={ano}
                onChange={(e) => setAno(e.target.value)}
                className={styles.select}
                required
              >
                {anosDisponiveis.map(a => (
                  <option key={a} value={a}>{a}</option>
                ))}
                {/* Fallback caso a lista venha vazia */}
                {anosDisponiveis.length === 0 && <option value={new Date().getFullYear()}>{new Date().getFullYear()}</option>}
              </select>
            </div>
          </div>

          <div className={styles.rowGrid}>
            <div className={styles.inputGroup}>
              <label>Tipo de Mídia *</label>
              <select
                value={tipoMidia}
                onChange={(e) => setTipoMidia(e.target.value)}
                className={styles.select}
              >
                <option value="foto">📷 Foto</option>
                <option value="video">🎬 Vídeo</option>
              </select>
            </div>

            <div className={styles.inputGroup}>
              <label>Status *</label>
              <select
                value={ativo ? 'true' : 'false'}
                onChange={(e) => setAtivo(e.target.value === 'true')}
                className={styles.select}
              >
                <option value="true">● Ativo (Visível)</option>
                <option value="false">○ Inativo (Oculto)</option>
              </select>
            </div>
          </div>

          <div className={styles.modalActions}>
            <button type="button" onClick={onClose} className={styles.cancelButton}>
              Cancelar
            </button>
            <button type="submit" className={styles.saveButton}>
              {midiaParaEditar ? 'Salvar Alterações' : 'Cadastrar Mídia'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}