// src/components/routes/ProtectedRoute.jsx
import { Navigate, Outlet } from 'react-router-dom';

export function ProtectedRoute() {
  const estaAutenticado = localStorage.getItem('mafe_autenticado') === 'true';

  // Se estiver logado, deixa passar para o painel. Se não, manda para o /login.
  return estaAutenticado ? <Outlet /> : <Navigate to="/login" replace />;
}