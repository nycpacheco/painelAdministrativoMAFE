// src/components/ui/MidiaDetailModal/MidiaDetailModal.jsx
import styles from './MidiaDetailModal.module.css';

export function MidiaDetailModal({ isOpen, onClose, midia, onEdit, onDelete, onToggleAtivo }) {
  if (!isOpen || !midia) return null;

  return (
    <div className={styles.backdrop}>
      <div className={styles.modal}>
        <div className={styles.modalHeader}>
          <h3>🔍 Detalhes da Mídia (ID: {midia.id})</h3>
          <button onClick={onClose} className={styles.closeButton}>✕</button>
        </div>

        <div className={styles.modalBody}>
          {/* Lado da Mídia (Destaque Principal) */}
          <div className={styles.mediaContainer}>
            {midia.url_midia ? (
              <img src={midia.url_midia} alt={midia.titulo} className={styles.largeImage} />
            ) : (
              <div className={styles.noMedia}>Sem mídia disponível</div>
            )}
          </div>

          {/* Lado das Informações (Metadados completos) */}
          <div className={styles.infoContainer}>
            <div className={styles.badgesRow}>
              <span className={styles.tipoBadge}>{midia.tipo_midia === 'video' ? '🎬 Vídeo' : '📷 Foto'}</span>
              <span className={midia.ativo ? styles.statusAtivo : styles.statusInativo}>
                {midia.ativo ? '● Ativo' : '○ Inativo'}
              </span>
              <span className={styles.anoBadge}>Ano: {midia.ano}</span>
            </div>

            <h2 className={styles.titulo}>{midia.titulo}</h2>
            
            <div className={styles.metaInfo}>
              <p><strong>Categoria ID:</strong> {midia.categoria_id}</p>
              <p><strong>Visualizações:</strong> {midia.visualizacoes}</p>
            </div>

            <div className={styles.descricaoBox}>
              <strong>Descrição Completa:</strong>
              <p>{midia.descricao || 'Nenhuma descrição informada.'}</p>
            </div>
          </div>
        </div>

        {/* Ações Rápidas Integradas */}
        <div className={styles.modalActions}>
          <button 
            onClick={() => onToggleAtivo(midia)} 
            className={midia.ativo ? styles.deactivateButton : styles.activateButton}
          >
            {midia.ativo ? 'Desativar' : 'Ativar'}
          </button>
          <button 
            onClick={() => { onClose(); onEdit(midia); }} 
            className={styles.editButton}
          >
            ✏️ Editar
          </button>
          <button 
            onClick={() => { if(confirm("Deseja excluir permanentemente esta mídia?")) { onDelete(midia.id); onClose(); } }} 
            className={styles.deleteButton}
          >
            🗑️ Excluir
          </button>
          <button onClick={onClose} className={styles.closeModalButton}>
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}