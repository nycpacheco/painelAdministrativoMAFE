// src/components/tabs/CategoriasTab/CategoriasTab.jsx
import { useState, useEffect } from 'react';
import { api } from '../../../services/api';
import styles from './CategoriasTab.module.css';

export function CategoriasTab() {
  const [categorias, setCategorias] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [novaCategoriaNome, setNovaCategoriaNome] = useState('');

  // Controle de edição inline por ID
  const [idEditando, setIdEditando] = useState(null);
  const [nomeEdicao, setNomeEdicao] = useState('');

  useEffect(() => {
    async function carregarDados() {
      try {
        const dados = await api.categorias.listar();
        setCategorias(dados);
      } catch (erro) {
        console.error("Erro ao carregar categorias:", erro);
      } finally {
        setCarregando(false);
      }
    }
    carregarDados();
  }, []);

  const handleCriarCategoria = async (e) => {
    e.preventDefault();
    if (!novaCategoriaNome.trim()) return;

    if (confirm("Deseja realmente criar esta nova categoria?")) {
      try {
        const nova = await api.categorias.criar({ nome: novaCategoriaNome.trim() });
        setCategorias([...categorias, nova]);
        setNovaCategoriaNome('');
        alert("Categoria criada com sucesso!");
      } catch (erro) {
        alert("Erro ao criar categoria.");
      }
    }
  };

  const handleIniciarEdicao = (cat) => {
    setIdEditando(cat.id);
    setNomeEdicao(cat.nome);
  };

  const handleCancelarEdicao = () => {
    setIdEditando(null);
    setNomeEdicao('');
  };

  const handleSalvarEdicao = async (id) => {
    if (!nomeEdicao.trim()) return;

    if (confirm("Deseja realmente salvar as alterações desta categoria?")) {
      try {
        const atualizada = await api.categorias.atualizar(id, { nome: nomeEdicao.trim() });
        setCategorias(categorias.map(c => c.id === id ? atualizada : c));
        setIdEditando(null);
        setNomeEdicao('');
        alert("Categoria atualizada com sucesso!");
      } catch (erro) {
        alert("Erro ao atualizar categoria.");
      }
    }
  };

  const handleDeletar = async (id) => {
    if (confirm("Tem certeza que deseja excluir esta categoria?")) {
      try {
        await api.categorias.deletar(id);
        setCategorias(categorias.filter(c => c.id !== id));
      } catch (erro) {
        alert("Erro ao excluir categoria.");
      }
    }
  };

  if (carregando) return <p style={{ color: '#888' }}>Carregando categorias...</p>;

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h3>Gerenciamento de Categorias</h3>
      </div>

      {/* Formulário para Criar Nova Categoria */}
      <form onSubmit={handleCriarCategoria} className={styles.createCard}>
        <h4>Adicionar Nova Categoria</h4>
        <div className={styles.createRow}>
          <input
            type="text"
            placeholder="Nome da nova categoria..."
            value={novaCategoriaNome}
            onChange={(e) => setNovaCategoriaNome(e.target.value)}
            className={styles.input}
            required
          />
          <button type="submit" className={styles.addButton}>
            + Adicionar
          </button>
        </div>
      </form>

      {/* Listagem de Categorias */}
      <div className={styles.listContainer}>
        <h4>Categorias Cadastradas ({categorias.length})</h4>

        {categorias.length === 0 ? (
          <p className={styles.emptyText}>Nenhuma categoria cadastrada.</p>
        ) : (
          <div className={styles.grid}>
            {categorias.map(cat => (
              <div key={cat.id} className={styles.categoryCard}>
                {idEditando === cat.id ? (
                  <div className={styles.editMode}>
                    <input
                      type="text"
                      value={nomeEdicao}
                      onChange={(e) => setNomeEdicao(e.target.value)}
                      className={styles.input}
                    />
                    <div className={styles.cardActions}>
                      <button onClick={() => handleSalvarEdicao(cat.id)} className={styles.saveButton}>
                        Salvar
                      </button>
                      <button onClick={handleCancelarEdicao} className={styles.cancelButton}>
                        Cancelar
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className={styles.viewMode}>
                    <div className={styles.info}>
                      <span className={styles.catId}>ID: {cat.id}</span>
                      <span className={styles.catName}>{cat.nome}</span>
                    </div>
                    <div className={styles.cardActions}>
                      <button onClick={() => handleIniciarEdicao(cat)} className={styles.editButton}>
                        Editar
                      </button>
                      <button onClick={() => handleDeletar(cat.id)} className={styles.deleteButton}>
                        Excluir
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}