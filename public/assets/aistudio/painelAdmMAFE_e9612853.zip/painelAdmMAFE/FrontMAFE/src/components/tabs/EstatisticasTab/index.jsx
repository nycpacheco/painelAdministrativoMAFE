// src/components/tabs/EstatisticasTab/EstatisticasTab.jsx
import { useState, useEffect } from 'react';
import { api } from '../../../services/api';
import styles from './EstatisticasTab.module.css';

export function EstatisticasTab() {
  const [estatisticas, setEstatisticas] = useState({
    quantidade_participantes: 0,
    quantidade_torneios: 0,
    ano_fundacao: 2019
  });
  const [carregando, setCarregando] = useState(true);
  const [editando, setEditando] = useState(false);
  const [formData, setFormData] = useState({
    quantidade_participantes: 0,
    quantidade_torneios: 0
  });

  useEffect(() => {
    async function carregarDados() {
      try {
        const dados = await api.estatisticas.obter();
        setEstatisticas(dados);
        setFormData({
          quantidade_participantes: dados.quantidade_participantes || 0,
          quantidade_torneios: dados.quantidade_torneios || 0
        });
      } catch (erro) {
        console.error("Erro ao carregar estatísticas:", erro);
      } finally {
        setCarregando(false);
      }
    }
    carregarDados();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    // Garante apenas números inteiros válidos, limpando zeros à esquerda automáticos
    const valorLimpo = value === '' ? '' : Math.max(0, parseInt(value, 10) || 0);
    setFormData(prev => ({
      ...prev,
      [name]: valorLimpo
    }));
  };

  const handleCancelar = () => {
    setFormData({
      quantidade_participantes: estatisticas.quantidade_participantes,
      quantidade_torneios: estatisticas.quantidade_torneios
    });
    setEditando(false);
  };

  const handleSalvar = (e) => {
    e.preventDefault();
    if (confirm("Deseja realmente atualizar as estatísticas do projeto?")) {
      async function salvar() {
        try {
          const novosDados = {
            ...estatisticas,
            quantidade_participantes: Number(formData.quantidade_participantes),
            quantidade_torneios: Number(formData.quantidade_torneios)
          };
          const atualizadas = await api.estatisticas.atualizar(novosDados);
          setEstatisticas(atualizadas);
          setEditando(false);
          alert("Estatísticas atualizadas com sucesso!");
        } catch (erro) {
          console.error("Erro ao salvar estatísticas:", erro);
          alert("Erro ao atualizar as estatísticas.");
        }
      }
      salvar();
    }
  };

  if (carregando) return <p style={{ color: '#888' }}>Carregando estatísticas...</p>;

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h3>📊 Gerenciamento de Estatísticas do Projeto</h3>
        {!editando && (
          <button className={styles.editButton} onClick={() => setEditando(true)}>
            ✏️ Editar Estatísticas
          </button>
        )}
      </div>

      <form onSubmit={handleSalvar} className={styles.formCard}>
        <div className={styles.inputGroup}>
          <label>Quantidade de Participantes</label>
          <input
            type="number"
            name="quantidade_participantes"
            value={formData.quantidade_participantes}
            onChange={handleChange}
            disabled={!editando}
            className={styles.input}
            min="0"
            required
          />
        </div>

        <div className={styles.inputGroup}>
          <label>Quantidade de Torneios / Campeonatos</label>
          <input
            type="number"
            name="quantidade_torneios"
            value={formData.quantidade_torneios}
            onChange={handleChange}
            disabled={!editando}
            className={styles.input}
            min="0"
            required
          />
        </div>

        {editando && (
          <div className={styles.actionsRow}>
            <button type="button" onClick={handleCancelar} className={styles.cancelButton}>
              Cancelar
            </button>
            <button type="submit" className={styles.saveButton}>
              Salvar Alterações
            </button>
          </div>
        )}
      </form>
    </div>
  );
}