// src/components/routes/AdminDashboard/AdminDashboard.jsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './AdminDashboard.module.css';

// 1. Importando os componentes de cada aba da pasta correta
import { MidiasTab } from '../../tabs/MidiasTab';
import { CategoriasTab } from '../../tabs/CategoriasTab';
import { ApoiadoresTab } from '../../tabs/ApoiadoresTab';
import { EstatisticasTab } from '../../tabs/EstatisticasTab';

export function AdminDashboard() {
  // 2. Estado que guarda qual aba está ativa (começa em 'midias')
  const [abaAtiva, setAbaAtiva] = useState('midias');
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('mafe_autenticado');
    navigate('/login');
  };

  // 3. Função inteligente que decide qual componente renderizar com base no estado
  const renderizarAba = () => {
    switch (abaAtiva) {
      case 'midias':
        return <MidiasTab />;
      case 'categorias':
        return <CategoriasTab />;
      case 'apoiadores':
        return <ApoiadoresTab />;
      case 'estatisticas':
        return <EstatisticasTab />;
      default:
        return <MidiasTab />;
    }
  };

  return (
    <div className={styles.dashboardContainer}>
      {/* Menu Lateral (Sidebar) */}
      <aside className={styles.sidebar}>
        <div>
          <h2 className={styles.sidebarTitle}>Painel MAFE</h2>
          <ul className={styles.navList}>
            <li>
              <button 
                onClick={() => setAbaAtiva('midias')}
                className={`${styles.navButton} ${abaAtiva === 'midias' ? styles.navButtonActive : ''}`}
              >
                📁 Mídias (Galeria)
              </button>
            </li>
            <li>
              <button 
                onClick={() => setAbaAtiva('categorias')}
                className={`${styles.navButton} ${abaAtiva === 'categorias' ? styles.navButtonActive : ''}`}
              >
                🏷️ Categorias
              </button>
            </li>
            <li>
              <button 
                onClick={() => setAbaAtiva('apoiadores')}
                className={`${styles.navButton} ${abaAtiva === 'apoiadores' ? styles.navButtonActive : ''}`}
              >
                🤝 Apoiadores
              </button>
            </li>
            <li>
              <button 
                onClick={() => setAbaAtiva('estatisticas')}
                className={`${styles.navButton} ${abaAtiva === 'estatisticas' ? styles.navButtonActive : ''}`}
              >
                📊 Estatísticas
              </button>
            </li>
          </ul>
        </div>

        <button onClick={handleLogout} className={styles.logoutButton}>
          Sair do Sistema
        </button>
      </aside>

      {/* Conteúdo Principal onde a aba é injetada */}
      <main className={styles.mainContent}>
        <header className={styles.header}>
          <span className={styles.badge}>Você está em: {abaAtiva}</span>
          <h1 className={styles.title}>Gerenciamento de {abaAtiva}</h1>
        </header>

        {/* O card carrega dinamicamente o componente da aba selecionada */}
        <div className={styles.card}>
          {renderizarAba()}
        </div>
      </main>
    </div>
  );
}