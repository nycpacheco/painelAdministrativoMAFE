// src/components/routes/Login.jsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../../services/api'; // Ajuste o caminho relativo conforme a sua estrutura de pastas
import styles from './Login.module.css';

export function Login() {
  const [usuario, setUsuario] = useState('');
  const [senha, setSenha] = useState('');
  const [carregando, setCarregando] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setCarregando(true);

    try {
      await api.auth.login(usuario, senha);
      navigate('/admin');
    } catch (err) {
      alert(err.message || 'Usuário ou senha incorretos!');
    } finally {
      setCarregando(false);
    }
  };

  return (
    <div className={styles.loginContainer}>
      <form onSubmit={handleLogin} className={styles.loginForm}>
        <h2 className={styles.loginTitle}>Admin MAFE</h2>
        
        <div className={styles.inputGroup}>
          <label>Usuário</label>
          <input 
            type="text" 
            value={usuario} 
            onChange={(e) => setUsuario(e.target.value)} 
            required
          />
        </div>

        <div className={styles.inputGroup}>
          <label>Senha</label>
          <input 
            type="password" 
            value={senha} 
            onChange={(e) => setSenha(e.target.value)} 
            required
          />
        </div>

        <button type="submit" disabled={carregando} className={styles.loginButton}>
          {carregando ? 'Entrando...' : 'Entrar'}
        </button>
      </form>
    </div>
  );
}