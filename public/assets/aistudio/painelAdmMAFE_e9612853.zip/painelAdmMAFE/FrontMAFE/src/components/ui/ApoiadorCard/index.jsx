// src/components/ui/ApoiadorCard/ApoiadorCard.jsx
import styles from './ApoiadorCard.module.css';

export function ApoiadorCard({ apoiador, onDelete, onEdit, onToggleAtivo, onViewDetails }) {
  return (
    <div className={`${styles.card} ${!apoiador.ativo ? styles.inativo : ''}`}>
      {apoiador.logo_url && (
        <div className={styles.imageContainer} onClick={() => onViewDetails && onViewDetails(apoiador)} title="Ampliar logo">
          <img src={apoiador.logo_url} alt={apoiador.nome_empresa} className={styles.thumbnail} />
          <div className={styles.zoomOverlay}>
            <span>🔍 Ampliar</span>
          </div>
        </div>
      )}
      
      <div className={styles.cardContent}>
        <div className={styles.headerCard}>
          <div className={styles.badges}>
            <span className={apoiador.ativo ? styles.statusAtivo : styles.statusInativo}>
              {apoiador.ativo ? 'Ativo' : 'Inativo'}
            </span>
          </div>
          <span className={styles.idBadge}>ID: {apoiador.id}</span>
        </div>
        <h4 className={styles.titulo}>{apoiador.nome_empresa}</h4>
        {apoiador.site_url && (
          <a href={apoiador.site_url} target="_blank" rel="noopener noreferrer" className={styles.siteLink}>
            🌐 {apoiador.site_url}
          </a>
        )}
        <p className={styles.descricao}>{apoiador.descricao}</p>
      </div>

      <div className={styles.footerCard}>
        <span className={styles.visualizacoes}>
          {apoiador.visualizacoes || 0} visualizações
        </span>
        <div className={styles.actions}>
          <button
            onClick={() => onViewDetails && onViewDetails(apoiador)}
            className={styles.detailButton}
            title="Ver detalhes"
          >
            Detalhes
          </button>
          <button
            onClick={() => onToggleAtivo(apoiador)}
            className={apoiador.ativo ? styles.deactivateButton : styles.activateButton}
            title={apoiador.ativo ? 'Desativar apoiador' : 'Ativar apoiador'}
          >
            {apoiador.ativo ? 'Desativar' : 'Ativar'}
          </button>
          <button
            onClick={() => onEdit(apoiador)}
            className={styles.editButton}
          >
            Editar
          </button>
          <button
            onClick={() => onDelete(apoiador.id)}
            className={styles.deleteButton}
            title="Excluir permanentemente"
          >
            Excluir
          </button>
        </div>
      </div>
    </div>
  );
}