// src/components/ui/MidiaCard/MidiaCard.jsx
import styles from './MidiaCard.module.css';

export function MidiaCard({ midia, onDelete, onEdit, onToggleAtivo, onViewDetails }) {
  return (
    <div className={`${styles.card} ${!midia.ativo ? styles.inativo : ''}`}>
      {/* Exibe a imagem com suporte a clique para ampliar */}
      {midia.url_midia && (
        <div className={styles.imageContainer} onClick={() => onViewDetails && onViewDetails(midia)} title="Ampliar imagem">
          <img src={midia.url_midia} alt={midia.titulo} className={styles.thumbnail} />
          <div className={styles.zoomOverlay}>
            <span>🔍 Ampliar</span>
          </div>
        </div>
      )}
      
      <div className={styles.cardContent}>
        <div className={styles.headerCard}>
          <div className={styles.badges}>
            <span className={styles.tipoBadge}>
              {midia.tipo_midia === 'video' ? 'Vídeo' : 'Foto'}
            </span>
            <span className={midia.ativo ? styles.statusAtivo : styles.statusInativo}>
              {midia.ativo ? 'Ativo' : 'Inativo'}
            </span>
          </div>
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            <span className={styles.idBadge}>ID: {midia.id}</span>
            <span className={styles.ano}>Ano: {midia.ano}</span>
          </div>
        </div>
        <h4 className={styles.titulo}>{midia.titulo}</h4>
        <p className={styles.descricao}>{midia.descricao}</p>
      </div>

      <div className={styles.footerCard}>
        <span className={styles.visualizacoes}>
          {midia.visualizacoes} visualizações
        </span>
        <div className={styles.actions}>
          <button
            onClick={() => onViewDetails && onViewDetails(midia)}
            className={styles.detailButton}
            title="Ver detalhes"
          >
            Detalhes
          </button>
          <button
            onClick={() => onToggleAtivo(midia)}
            className={midia.ativo ? styles.deactivateButton : styles.activateButton}
            title={midia.ativo ? 'Desativar mídia' : 'Ativar mídia'}
          >
            {midia.ativo ? 'Desativar' : 'Ativar'}
          </button>
          <button
            onClick={() => onEdit(midia)}
            className={styles.editButton}
          >
            Editar
          </button>
          <button
            onClick={() => onDelete(midia.id)}
            className={styles.deleteButton}
            title="Excluir permanentemente"
          >
            Excluir
          </button>
        </div>
      </div>
    </div>
  );
}