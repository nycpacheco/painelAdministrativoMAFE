// src/components/tabs/ApoiadoresTab/ApoiadoresTab.jsx
import { useState, useEffect } from 'react';
import { api } from '../../../services/api';
import { ApoiadorCard } from '../../ui/ApoiadorCard';
import { ApoiadorModal } from '../../ui/ApoiadorModal';
import { ApoiadorDetailModal } from '../../ui/ApoiadorDetailModal';
import styles from './ApoiadoresTab.module.css';

export function ApoiadoresTab() {
  const [apoiadores, setApoiadores] = useState([]);
  const [carregando, setCarregando] = useState(true);

  // Estados dos Modais
  const [modalAberto, setModalAberto] = useState(false);
  const [apoiadorEmEdicao, setApoiadorEmEdicao] = useState(null);

  // Estados do Modal de Detalhes (Lightbox)
  const [modalDetalhesAberto, setModalDetalhesAberto] = useState(false);
  const [apoiadorSelecionadoDetalhes, setApoiadorSelecionadoDetalhes] = useState(null);

  useEffect(() => {
    async function carregarDados() {
      try {
        const dadosApoiadores = await api.apoiadores.listar();
        setApoiadores(dadosApoiadores);
      } catch (erro) {
        console.error("Erro ao carregar apoiadores:", erro);
      } finally {
        setCarregando(false);
      }
    }
    carregarDados();
  }, []);

  const handleDeleteApoiador = async (id) => {
    if (confirm("Tem certeza que deseja excluir permanentemente este apoiador?")) {
      try {
        await api.apoiadores.deletar(id);
        setApoiadores(apoiadores.filter(a => a.id !== id));
        setModalDetalhesAberto(false);
      } catch (erro) {
        alert("Erro ao excluir apoiador.");
      }
    }
  };

  const handleToggleAtivo = async (apoiador) => {
    try {
      const novoStatus = !apoiador.ativo;
      await api.apoiadores.atualizar(apoiador.id, { ativo: novoStatus });
      setApoiadores(apoiadores.map(a => a.id === apoiador.id ? { ...a, ativo: novoStatus } : a));
      if (apoiadorSelecionadoDetalhes && apoiadorSelecionadoDetalhes.id === apoiador.id) {
        setApoiadorSelecionadoDetalhes(prev => ({ ...prev, ativo: novoStatus }));
      }
    } catch (erro) {
      alert("Erro ao alterar status do apoiador.");
    }
  };

  // Funções de Controle dos Modais
  const abrirModalCriacao = () => {
    setApoiadorEmEdicao(null);
    setModalAberto(true);
  };

  const abrirModalEdicao = (apoiador) => {
    setApoiadorEmEdicao(apoiador);
    setModalAberto(true);
  };

  const abrirModalDetalhes = (apoiador) => {
    setApoiadorSelecionadoDetalhes(apoiador);
    setModalDetalhesAberto(true);
  };

  const handleSalvarApoiador = async (dadosFormulario) => {
    try {
      if (apoiadorEmEdicao) {
        const atualizado = await api.apoiadores.atualizar(apoiadorEmEdicao.id, dadosFormulario);
        setApoiadores(apoiadores.map(a => a.id === apoiadorEmEdicao.id ? atualizado : a));
        if (apoiadorSelecionadoDetalhes && apoiadorSelecionadoDetalhes.id === apoiadorEmEdicao.id) {
          setApoiadorSelecionadoDetalhes(atualizado);
        }
      } else {
        const novo = await api.apoiadores.criar(dadosFormulario);
        setApoiadores([novo, ...apoiadores]);
      }
      setModalAberto(false);
      setApoiadorEmEdicao(null);
    } catch (erro) {
      alert("Erro ao salvar o apoiador.");
    }
  };

  if (carregando) return <p style={{ color: '#888' }}>Carregando apoiadores...</p>;

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h3>🤝 Gerenciamento de Apoiadores e Patrocinadores</h3>
        <button className={styles.addButton} onClick={abrirModalCriacao}>
          + Adicionar Novo Apoiador
        </button>
      </div>

      <p className={styles.counter}>
        Mostrando <strong>{apoiadores.length}</strong> apoiadores cadastrados.
      </p>

      {apoiadores.length === 0 ? (
        <div className={styles.emptyState}>
          <p>Nenhum apoiador cadastrado.</p>
        </div>
      ) : (
        <div className={styles.grid}>
          {apoiadores.map(apoiador => (
            <ApoiadorCard 
              key={apoiador.id} 
              apoiador={apoiador} 
              onDelete={handleDeleteApoiador} 
              onEdit={abrirModalEdicao}
              onToggleAtivo={handleToggleAtivo}
              onViewDetails={abrirModalDetalhes}
            />
          ))}
        </div>
      )}

      {/* Componente Modal de Criação/Edição */}
      <ApoiadorModal
        isOpen={modalAberto}
        onClose={() => setModalAberto(false)}
        onSave={handleSalvarApoiador}
        apoiadorParaEditar={apoiadorEmEdicao}
      />

      {/* Componente Pop-up de Detalhes (Lightbox) */}
      <ApoiadorDetailModal
        isOpen={modalDetalhesAberto}
        onClose={() => setModalDetalhesAberto(false)}
        apoiador={apoiadorSelecionadoDetalhes}
        onEdit={(a) => { setModalDetalhesAberto(false); abrirModalEdicao(a); }}
        onDelete={handleDeleteApoiador}
        onToggleAtivo={handleToggleAtivo}
      />
    </div>
  );
}