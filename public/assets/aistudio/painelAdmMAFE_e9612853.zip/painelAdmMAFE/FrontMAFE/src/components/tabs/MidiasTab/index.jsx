// src/components/tabs/MidiasTab/MidiasTab.jsx
import { useState, useEffect } from 'react';
import { api } from '../../../services/api';
import { MidiaCard } from '../../ui/MidiaCard';
import { MidiaModal } from '../../ui/MidiaModal';
import { MidiaDetailModal } from '../../ui/MidiaDetailModal';
import styles from './MidiasTab.module.css';

export function MidiasTab() {
  const [midias, setMidias] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [carregando, setCarregando] = useState(true);

  // Estados dos Filtros
  const [busca, setBusca] = useState('');
  const [filtroCategoria, setFiltroCategoria] = useState('');
  const [filtroAno, setFiltroAno] = useState('');
  const [filtroStatus, setFiltroStatus] = useState('');
  const [filtroTipo, setFiltroTipo] = useState('');

  // Estados do Modal de Criação/Edição
  const [modalAberto, setModalAberto] = useState(false);
  const [midiaEmEdicao, setMidiaEmEdicao] = useState(null);

  // Estados do Modal de Detalhes (Lightbox)
  const [modalDetalhesAberto, setModalDetalhesAberto] = useState(false);
  const [midiaSelecionadaDetalhes, setMidiaSelecionadaDetalhes] = useState(null);

  useEffect(() => {
    async function carregarDados() {
      try {
        const [dadosMidias, dadosCategorias] = await Promise.all([
          api.midias.listar(),
          api.categorias.listar()
        ]);
        setMidias(dadosMidias);
        setCategorias(dadosCategorias);
      } catch (erro) {
        console.error("Erro ao carregar dados da aba Midias:", erro);
      } finally {
        setCarregando(false);
      }
    }
    carregarDados();
  }, []);

  const anosDisponiveis = [...new Set(midias.map(m => m.ano))].sort((a, b) => b - a);

  // Lógica de Filtros Combinados
  const midiasFiltradas = midias.filter(midia => {
    const termoBusca = busca.toLowerCase().trim();
    const matchBusca = !termoBusca || 
      midia.titulo.toLowerCase().includes(termoBusca) || 
      String(midia.id).includes(termoBusca);

    const matchCategoria = !filtroCategoria || String(midia.categoria_id) === String(filtroCategoria);
    const matchAno = !filtroAno || String(midia.ano) === String(filtroAno);
    
    const matchStatus = !filtroStatus || 
      (filtroStatus === 'ativo' && midia.ativo) || 
      (filtroStatus === 'inativo' && !midia.ativo);

    const matchTipo = !filtroTipo || midia.tipo_midia === filtroTipo;

    return matchBusca && matchCategoria && matchAno && matchStatus && matchTipo;
  });

  const limparFiltros = () => {
    setBusca('');
    setFiltroCategoria('');
    setFiltroAno('');
    setFiltroStatus('');
    setFiltroTipo('');
  };

  const handleDeleteMidia = async (id) => {
    if (confirm("Tem certeza que deseja excluir permanentemente esta mídia?")) {
      try {
        await api.midias.deletar(id);
        setMidias(midias.filter(m => m.id !== id));
        setModalDetalhesAberto(false);
      } catch (erro) {
        alert("Erro ao excluir mídia.");
      }
    }
  };

  const handleToggleAtivo = async (midia) => {
    try {
      const novoStatus = !midia.ativo;
      await api.midias.atualizar(midia.id, { ativo: novoStatus });
      
      setMidias(midias.map(m => m.id === midia.id ? { ...m, ativo: novoStatus } : m));
      
      if (midiaSelecionadaDetalhes && midiaSelecionadaDetalhes.id === midia.id) {
        setMidiaSelecionadaDetalhes(prev => ({ ...prev, ativo: novoStatus }));
      }
    } catch (erro) {
      alert("Erro ao alterar status da mídia.");
    }
  };

  // Funções de Controle dos Modais
  const abrirModalCriacao = () => {
    setMidiaEmEdicao(null);
    setModalAberto(true);
  };

  const abrirModalEdicao = (midia) => {
    setMidiaEmEdicao(midia);
    setModalAberto(true);
  };

  const abrirModalDetalhes = (midia) => {
    setMidiaSelecionadaDetalhes(midia);
    setModalDetalhesAberto(true);
  };

  const handleSalvarMidia = async (dadosFormulario) => {
    try {
      if (midiaEmEdicao) {
        const atualizada = await api.midias.atualizar(midiaEmEdicao.id, dadosFormulario);
        setMidias(midias.map(m => m.id === midiaEmEdicao.id ? atualizada : m));
        
        if (midiaSelecionadaDetalhes && midiaSelecionadaDetalhes.id === midiaEmEdicao.id) {
          setMidiaSelecionadaDetalhes(atualizada);
        }
      } else {
        const nova = await api.midias.criar(dadosFormulario);
        setMidias([nova, ...midias]);
      }
      setModalAberto(false);
      setMidiaEmEdicao(null);
    } catch (erro) {
      alert("Erro ao salvar a mídia.");
    }
  };

  if (carregando) return <p style={{ color: '#888' }}>A carregar mídias e filtros...</p>;

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h3>Gerenciamento de Mídias e Galeria</h3>
        <button className={styles.addButton} onClick={abrirModalCriacao}>
          + Adicionar Nova Mídia
        </button>
      </div>

      {/* Painel de Filtros e Pesquisa */}
      <div className={styles.filterPanel}>
        <div className={styles.searchRow}>
          <input
            type="text"
            placeholder="Pesquisar por título ou ID da mídia..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            className={styles.searchInput}
          />
        </div>

        <div className={styles.filterRow}>
          <select
            value={filtroCategoria}
            onChange={(e) => setFiltroCategoria(e.target.value)}
            className={styles.select}
          >
            <option value="">Todas as Categorias</option>
            {categorias.map(cat => (
              <option key={cat.id} value={cat.id}>{cat.nome}</option>
            ))}
          </select>

          <select
            value={filtroAno}
            onChange={(e) => setFiltroAno(e.target.value)}
            className={styles.select}
          >
            <option value="">Todos os Anos</option>
            {anosDisponiveis.map(ano => (
              <option key={ano} value={ano}>{ano}</option>
            ))}
          </select>

          <select
            value={filtroTipo}
            onChange={(e) => setFiltroTipo(e.target.value)}
            className={styles.select}
          >
            <option value="">Todos os Tipos</option>
            <option value="foto">Foto</option>
            <option value="video">Vídeo</option>
          </select>

          <select
            value={filtroStatus}
            onChange={(e) => setFiltroStatus(e.target.value)}
            className={styles.select}
          >
            <option value="">Todos os Status</option>
            <option value="ativo">Ativos</option>
            <option value="inativo">Inativos</option>
          </select>

          {(busca || filtroCategoria || filtroAno || filtroStatus || filtroTipo) && (
            <button onClick={limparFiltros} className={styles.clearButton}>
              ✕ Limpar Filtros
            </button>
          )}
        </div>
      </div>

      <p className={styles.counter}>
        A mostrar <strong>{midiasFiltradas.length}</strong> de {midias.length} mídias cadastradas.
      </p>

      {midiasFiltradas.length === 0 ? (
        <div className={styles.emptyState}>
          <p>Nenhuma mídia encontrada com os filtros selecionados.</p>
        </div>
      ) : (
        <div className={styles.grid}>
          {midiasFiltradas.map(midia => (
            <MidiaCard
              key={midia.id}
              midia={midia}
              onDelete={handleDeleteMidia}
              onEdit={abrirModalEdicao}
              onToggleAtivo={handleToggleAtivo}
              onViewDetails={abrirModalDetalhes}
            />
          ))}
        </div>
      )}

      {/* Componente Modal Reutilizável de Criação/Edição */}
      <MidiaModal
        isOpen={modalAberto}
        onClose={() => setModalAberto(false)}
        onSave={handleSalvarMidia}
        midiaParaEditar={midiaEmEdicao}
        categorias={categorias}
        anosDisponiveis={anosDisponiveis}
      />

      {/* Componente Pop-up de Detalhes (Lightbox) */}
      <MidiaDetailModal
        isOpen={modalDetalhesAberto}
        onClose={() => setModalDetalhesAberto(false)}
        midia={midiaSelecionadaDetalhes}
        onEdit={(m) => { setModalDetalhesAberto(false); abrirModalEdicao(m); }}
        onDelete={handleDeleteMidia}
        onToggleAtivo={handleToggleAtivo}
      />
    </div>
  );
}