import os
from werkzeug.security import generate_password_hash

def normalizar_database_uri(uri: str) -> str:
    """
    Normaliza a URI de conexão para garantir compatibilidade com PyMySQL
    e provedores de banco de dados MySQL em nuvem (Railway, Aiven, TiDB, Render, etc.).
    """
    if not uri:
        return uri
    uri = uri.strip()
    # Se a URI começar com 'mysql://', ajusta para 'mysql+pymysql://'
    if uri.startswith("mysql://"):
        uri = uri.replace("mysql://", "mysql+pymysql://", 1)
    return uri

class Config:
    # =========================================================================
    # >>> [COLOCAR DATABASE AQUI] <<<
    # Cole aqui a string de conexão do seu banco de dados MySQL online ou local:
    # Exemplo Nuvem/Remoto: mysql+pymysql://usuario:senha@host-nuvem.com:porta/mafe_db
    # (Se colar 'mysql://...', o sistema converte automaticamente para PyMySQL)
    # =========================================================================
    RAW_DATABASE_URI = os.getenv(
        "DATABASE_URL",
        "mysql+pymysql://root:3006@localhost:3306/mafe_db"  # <<< [COLOCAR DATABASE AQUI]
    )

    SQLALCHEMY_DATABASE_URI = normalizar_database_uri(RAW_DATABASE_URI)
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Opções essenciais para bancos de dados em nuvem (evitam quedas de conexão por ociosidade)
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,  # Testa a conexão antes de executar query (evita 'MySQL server has gone away')
        "pool_recycle": 280     # Recicla conexões antes do timeout do provedor (padrão nuvem: ~300s)
    }
    
    # Credenciais de Administrador da Coordenação
    ADMIN_USER = os.getenv("ADMIN_USER", "coordenacao")
    ADMIN_PASSWORD_HASH = generate_password_hash(os.getenv("ADMIN_PASSWORD", "123456"))

