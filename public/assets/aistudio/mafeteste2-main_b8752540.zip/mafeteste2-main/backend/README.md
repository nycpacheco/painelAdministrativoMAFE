# Backend MAFE - Flask & MySQL

Instruções para inicialização e conexão do Backend com o Painel Administrativo MAFE.

---

## 1. Onde Configurar o Banco de Dados (Local ou Nuvem Gratuita)

### Arquivo: `backend/config.py`
Localize a linha marcada com `[COLOCAR DATABASE AQUI]`:
```python
RAW_DATABASE_URI = os.getenv(
    "DATABASE_URL",
    "mysql+pymysql://root:3006@localhost:3306/mafe_db"  # <<< [COLOCAR DATABASE AQUI]
)
```

#### Como colar o link do Banco na Nuvem (Railway, Aiven, TiDB Cloud, Clever Cloud, etc.):
Geralmente esses serviços fornecem um link de conexão parecido com:
`mysql://usuario:senha@host-nuvem.com:porta/nome_do_banco`

Você pode colar diretamente esse link no lugar de `"mysql+pymysql://root:3006@localhost:3306/mafe_db"`.
O sistema em `config.py` foi programado para:
1. Converter automaticamente `mysql://` para `mysql+pymysql://` (evitando falha do driver MySQLdb).
2. Manter a conexão viva com `pool_pre_ping=True` e `pool_recycle=280` para evitar quedas por ociosidade do banco na nuvem.

---

## 2. Como Parar de Usar o Armazenamento Local Simulado (localStorage)

### Arquivo: `src/services/api.js`
No topo do arquivo, há duas variáveis de controle:
```javascript
// 1. Rota do Backend Flask:
export const API_BASE_URL = 'http://localhost:5000/api'; // [COLOCAR ROTA DE CONEXAO AQUI]

// 2. Chave de contingência:
export const USAR_STORAGE_CONTINGENCIA = true;
```

**Para parar de usar o armazenamento simulado:**
- Mude `USAR_STORAGE_CONTINGENCIA` de `true` para `false`:
  ```javascript
  export const USAR_STORAGE_CONTINGENCIA = false;
  ```
- **O que acontece ao mudar para `false`?**
  O front-end desativa todo o fallback de `localStorage`. Ele fará as requisições exclusivamente para o seu backend Flask conectado ao banco de dados MySQL online. Caso o backend caia ou o banco esteja inacessível, o front-end avisará o erro na tela imediatamente em vez de fingir que salvou no navegador.

---

## 4. Correções Realizadas no Backend

1. **Separação de DELETE e PATCH**:
   - `DELETE /api/admin/midias/<id>` agora executa a exclusão permanente no banco de dados através do método `midia.deletar()`.
   - `PATCH /api/admin/midias/<id>/status` permanece exclusivo para alternar o status ativo/inativo sem excluir.
   - `DELETE /api/admin/apoiadores/<id>` agora executa a exclusão permanente no banco de dados através do método `apoiador.deletar()`.
   - `PATCH /api/admin/apoiadores/<id>/status` permanece exclusivo para alternar o status ativo/inativo.

2. **Novas Rotas de Edição (PUT)**:
   - Adicionado `PUT /api/admin/midias/<id>` para salvar edições de mídias.
   - Adicionado `PUT /api/admin/apoiadores/<id>` para salvar edições de apoiadores.

3. **Métodos `deletar()` nos Models**:
   - Adicionado método `deletar(self)` em `Midia` e `Apoiador` no `models.py`.

4. **Tratamento de Exceções com HTTP 400**:
   - Adicionado tratamento `try...except ValueError` nas rotas de categorias para retornar erro HTTP 400 com mensagem amigável (impedindo exclusão de categorias com mídias vinculadas ou cadastro de categorias em branco/duplicadas).
