import os
import pymysql
from urllib.parse import urlparse

# =========================================================================
# >>> [COLOCAR DATABASE AQUI] <<<
# Você pode definir a URL do banco em nuvem ou parâmetros manuais:
# =========================================================================
DB_URL = os.getenv("DATABASE_URL", "")

if DB_URL:
    # Trata links de nuvem tipo mysql://usuario:senha@host:porta/banco
    parsed = urlparse(DB_URL.replace("mysql+pymysql://", "mysql://"))
    MYSQL_CONFIG = {
        "host": parsed.hostname or "localhost",
        "user": parsed.username or "root",
        "password": parsed.password or "",
        "port": parsed.port or 3306,
        "database": (parsed.path or "").lstrip("/") or "mafe_db"
    }
else:
    MYSQL_CONFIG = {
        "host": "localhost",      # <<< [COLOCAR DATABASE AQUI]
        "user": "root",           # <<< [COLOCAR DATABASE AQUI]
        "password": "3006",       # <<< [COLOCAR DATABASE AQUI]
        "port": 3306,             # <<< [COLOCAR DATABASE AQUI]
        "database": "mafe_db"
    }

try:
    conexao = pymysql.connect(
        host=MYSQL_CONFIG["host"],
        user=MYSQL_CONFIG["user"],
        password=MYSQL_CONFIG["password"],
        port=MYSQL_CONFIG["port"]
    )
    with conexao.cursor() as cursor:
        db_name = MYSQL_CONFIG.get("database", "mafe_db")
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
        print(f"Base de dados '{db_name}' verificada/criada com sucesso no MySQL!")
    conexao.close()
except Exception as e:
    print(f"Nota/Aviso ao conectar no MySQL: {e}")
    print("Em bancos de dados na nuvem, o banco já costuma vir criado previamente.")

